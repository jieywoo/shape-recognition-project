#include <math.h>

#include "myBmpGris.c"

#define N 10
//Destruction d'une Matrice
/**Methode de desallocation d'une matrice de double si elle existe
  *@param mat la matrice a desallouer
  *@param dim le nombre de lignes de la matrice
  */
void freeMatrice( double** mat, int dim)
{
    if( mat != NULL )
    {
        int i;
        for( i = 0; i < dim; i++ )
            free( mat[i] );
        free( mat );
    }
    mat = NULL;
}


/**Creation d'une matrice CoeffLeg d'ordre N contenant les coefficients de Legendre
  *@param CoeffLeg la matrice contenant que des 0s initialement
  *Apres l'execution de cette fonction, ces valeurs correspondent aux coefficients des polynomes de Legendre
  *La ligne correspond a l'ordre du polynome
  *La position dans une ligne correspond a la puissance de x
  *CoeffLeg[12][3] = le coeff de Legendre de x^3 pour le polynome d'ordre 12
  */
void createCoeffLeg(double** CoeffLeg)
{
    int inc1,inc2;

    CoeffLeg[0][0] = 1;
    CoeffLeg[1][1] = 1;

    for(inc1=2;inc1<N;inc1++)
        for(inc2=0;inc2<=inc1;inc2++)
            if  (!inc2)
                CoeffLeg[inc1][inc2] = -((inc1-1)*CoeffLeg[inc1-2][0])/inc1;
            else
                if (inc2 == inc1)
                    CoeffLeg[inc1][inc2] = ((2*inc1-1)*CoeffLeg[inc1-1][inc1-1])/inc1;
                else
                    CoeffLeg[inc1][inc2] = ((2*inc1-1)*CoeffLeg[inc1-1][inc2-1])/inc1 -((inc1-1)*CoeffLeg[inc1-2][inc2])/inc1;
}

/**Creation d'une matrice I contenant les positions (pixels) elevees a l'ordre p
  *@param I la matrice contenant que des 0s initialement
  *@param dim La dimension de l'image dans une direction (cette fonction peut ainsi etre utilisee peu importe la direction (x,y))
  *Apres l'execution de cette fonction, ces valeurs correspondent  (position_pixel^p)
  *La ligne correspond a la position (0-127 pour une image de 128 pixels dans la direction concernee)
  *La position dans une ligne correspond a la puissance de p
  *I[1][3] = pixel_position_1 ^ 3
  */
void createI(double** I,int dim)
{
    int i,j;

    for (i = 0; i < dim; i++)
        for (j = 0; j < N; j++)
            I[i][j] = pow(i,j);
}

/**Creation d'une matrice mat_mom contenant les moments d'ordre p+q
  *@param mat_mom la matrice contenant que des 0s initialement
  *@param Ix Une matrice contenant les positions x (en pixels)(correspond a la ligne) elevees a la puissance p (correspond a la colonne)
  *@param Iy Une matrice contenant les positions y (en pixels)(correspond a la ligne) elevees a la puissance q (correspond a la colonne)
  *@param fBin structure contenant les informations de l'image binaire
  *Apres l'execution de cette fonction, ces valeurs correspondent aux moments d'ordre p+q
  *La ligne correspond a p
  *La colonne correspond a q
  *M[p][q] = moment d'ordre p+q
  */
void createM(double** mat_mom,double** Ix,double** Iy,BmpImg fBin)
{
    int incp,incq,incx,incy;
    double somme;

    for (incp = 0; incp < N; incp++)
        for (incq = 0; incq < N - incp; incq++)
        {
            somme = 0;
            for (incx=0;incx<fBin.dimX; incx++)
                for (incy=0; incy<fBin.dimY; incy++)
                    somme += Ix[incx][incp]*Iy[incy][incq]*fBin.img[incx][incy];
            mat_mom[incp][incq] = somme;
        }
}

/**Creation d'une matrice mat_mom contenant les moments centres et normes d'ordre p+q
  *@param eta la matrice contenant que des 0s initialement
  *@param mat_mom Une matrice contenant les moments d'ordre p+q
  *@param fBin structure contenant les informations de l'image binaire
  *Apres l'execution de cette fonction, ces valeurs correspondent aux moments centres et normes d'ordre p+q
  *La ligne correspond a p
  *La colonne correspond a q
  *eta[p][q] = moment centre et norme d'ordre p+q
  */
void createEta(BmpImg fBin, double** mat_mom,double** eta)
{
        double m_0,x_centre,y_centre;
        int incp,incq,incx,incy;
        double xm,ym,somme;

        m_0 = mat_mom[0][0];
        x_centre=mat_mom[1][0]/m_0;
        y_centre=mat_mom[0][1]/m_0;

        for (incp = 0; incp < N; incp++)
            for (incq = 0; incq < N - incp; incq++)
            {
                somme  = 0;
                for (incx=0; incx<fBin.dimX; incx++)
                {
                    xm = incx - x_centre;
                    for (incy=0; incy<fBin.dimY; incy++)
                    {
                        ym = incy - y_centre;
                        somme += (pow(xm,incp))*(pow(ym,incq))*fBin.img[incx][incy]/(pow(m_0,0.5*(incp+incq+2)));
                    }
            }
            eta[incp][incq] = somme;
            }
}

/**Creation d'une matrice lambda contenant les moments centres et normes d'ordre p+q projete sur la base des polynomes de Legendre
  *@param lambda la matrice contenant que des 0s initialement
  *@param eta Une matrice contenant les moments centres et normes d'ordre p+q
  *@param CoeffLeg matrice contenant les coefficients des polynome de Legendre
  *Apres l'execution de cette fonction, ces valeurs correspondent aux moments centres et normes d'ordre p+q projetes sur la base des polynomes de Legendre
  *La ligne correspond a p
  *La colonne correspond a q
  *lambda[p][q] = moment centre et norme d'ordre p+q projete sur la base des polynomes de Legendre
  */
void createLambda(double** eta, double** CoeffLeg,double** lambda)
{
    int i,j,incp,incq;
    double res;

    for(incp = 0; incp < N ; incp++)
    {
        for(incq = 0; incq < N - incp; incq++)
        {
            res = 0;
            for (i = 0; i <= incp; i++)
                for (j = 0; j <= incq; j++)
                    res += CoeffLeg[incp][i] * CoeffLeg[incq][j] * eta[i][j] *((2*incp + 1)*(2*incq + 1))/4.0;
            lambda[incp][incq] = res;
        }
    }
}

/**Fonction qui retourne la valeur d'un polynome de Legendre d'ordre p en x.
  *@param x la coordonnee [-1,1]
  *@param p l'ordre du polynome
  *@param CoeffLeg Matrice avec les coefficients de Legendre
  */
double val_leg(double x,int p,double** CoeffLeg)
{
    if (!p) return 1;

    int i;
    double val = 0;

    for(i=0;i<=p;i++)
        val += (CoeffLeg[p][i] * pow(x,i));

    return val;
}

/**Fonction qui reconstruit une image a partir de lambda (matrice moments centres normes projetes)
  *@param fBin Structure contenant les informations de l'image bitmap
  *@param CoeffLeg Matrice des coefficients des polynomes de Legendre
  *@param lambda matrice moments centres normes projetes
  *@param rekt matrice de pixels "reconstruites" initialement a 0
  */
void createImRekt(BmpImg fBin,double** CoeffLeg, double** lambda,double** rekt)
{
    int incx,incy,incp,incq;
    double hx,hy;
    double x,y;
    double res;
    double valX;

    hx = 2.0/(fBin.dimX - 1);
    hy = 2.0/(fBin.dimY - 1);

    for(incx=0;incx<fBin.dimX;incx++)
    {
        x = -1.0 + incx*hx;
        for(incy=0;incy<fBin.dimY;incy++)
        {
            y = -1.0 + incy*hy;
            res = 0;
            for(incp=0;incp < N;incp++)
            {
                valX =val_leg(x,incp,CoeffLeg);
                for(incq=0;incq < N - incp;incq++)
                    res += (lambda[incp][incq] * valX * val_leg(y,incq,CoeffLeg));
            }
            rekt[incx][incy]=res;
        }
    }

    for(incx=0;incx<fBin.dimX;incx++)
        for(incy=0;incy<fBin.dimY;incy++)
            if(rekt[incx][incy]>= 0.5) fBin.img[incx][incy] = 255;
            else rekt[incx][incy]=0;
}


void readRef(double** mat,char* fName)
{
    int incp,incq;
    FILE* fBin = fopen(fName,"r");

    if(fBin)
    {
        for (incp=0;incp<N;incp++)
            for(incq=0;incq<N;incq++)
                if ((incq > N -1 - incp))
                    mat[incp][incq]=0;
                else
                    fscanf(fBin,"%lf",&mat[incp][incq]);
    }
    else
        printf("Lecture de la matrice de reference ECHOUEE ! Merci de reessayez !\n");

    fclose(fBin);
}

double calcDist(double** mat_ref,double** mat)
{
    int incp,incq;
    double res=0;

    for(incp=0;incp<N;incp++)
        for(incq=0;incq<N-incp;incq++)
            res += ((mat_ref[incp][incq]-mat[incp][incq])*(mat_ref[incp][incq]-mat[incp][incq]));
    res = sqrt(res);

    return res;
}

int main()
{
    int i,j;
    double dist_a,dist_c,dist_i,dist_carre;

    BmpImg fBin = readBmpImage("lettre_i.bmp");

    //"Conversion" en image binaire (0 = 0, 255 = 1)
    for(i=0;i<fBin.dimX;i++)
        for(j=0;j<fBin.dimY;j++)
            if(fBin.img[i][j]) fBin.img[i][j] = 1;

    //Creation des diverses matrices utilisees
    double** CoeffLeg = malloc(N*sizeof(double*));
    for(i=0;i<N;i++)
        CoeffLeg[i] = calloc(N,sizeof(double));

    createCoeffLeg(CoeffLeg);

    double** mat_mom = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        mat_mom[i] = calloc( N, sizeof(double) );


    double** eta = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        eta[i] = calloc( N, sizeof(double) );

    double** lambda = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        lambda[i] = calloc( N, sizeof(double) );

    double** lambda_carre = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        lambda_carre[i] = calloc( N, sizeof(double) );

    double** lambda_a = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        lambda_a[i] = calloc( N, sizeof(double) );

    double** lambda_c = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        lambda_c[i] = calloc( N, sizeof(double) );

    double** lambda_i = malloc( N * sizeof(double*) );
    for( i = 0; i < N; i++ )
        lambda_i[i] = calloc( N, sizeof(double) );

    double** rekt = malloc( fBin.dimX * sizeof(double*) );
    for( i = 0; i < fBin.dimX; i++ )
        rekt[i] = calloc( fBin.dimY, sizeof(double) );

    double** Ix = malloc( (fBin.dimX) * sizeof(double*) );
    for( i = 0; i < fBin.dimX; i++ )
        Ix[i] = calloc( N, sizeof(double) );

    double** Iy = malloc( (fBin.dimY) * sizeof(double*) );
    for( i = 0; i < fBin.dimY; i++ )
        Iy[i] = calloc( N, sizeof(double) );

    createI(Ix,fBin.dimX);
    createI(Iy,fBin.dimY);

    createM(mat_mom,Ix,Iy,fBin);

    createEta(fBin,mat_mom,eta);

    createLambda(eta,CoeffLeg,lambda);

    createImRekt(fBin,CoeffLeg,lambda,rekt);

    //Ecriture de l'image
    writeBmpImage("recons_test_aaa.bmp",&fBin);

    //Reconnaissance
    readRef(lambda_i,"REF_I.txt");
    readRef(lambda_c,"REF_C.txt");
    readRef(lambda_a,"REF_A.txt");
    readRef(lambda_carre,"REF_carre.txt");

    dist_carre = calcDist(lambda_carre,lambda);
    dist_a = calcDist(lambda_a,lambda);
    dist_c = calcDist(lambda_c,lambda);
    dist_i = calcDist(lambda_i,lambda);

    if(dist_carre < dist_a)
        if(dist_carre<dist_c)
            if(dist_carre<dist_i)
                printf("C'est semblable a un carre !\n");
            else
                printf("C'est semblable a la lettre I !\n");
        else
            if(dist_c<dist_i)
                printf("C'est semblable a la lettre C !\n");
            else
                printf("C'est semblable a la lettre I !\n");
    else
        if(dist_a<dist_c)
            if(dist_a<dist_i)
                printf("C'est semblable a la lettre A |\n");
            else
                printf("C'est semblable a la lettre I !\n");
        else
            if(dist_c<dist_i)
                printf("C'est semblable a la lettre C !\n");
            else
                printf("C'est semblable a la lettre I !\n");



    //Desallocation des Matrices
    freeMatrice(rekt,fBin.dimY);
    freeMatrice(Ix,fBin.dimX);
    freeMatrice(Iy,fBin.dimY);
    freeMatrice(lambda,N);
    freeMatrice(lambda_a,N);
    freeMatrice(lambda_c,N);
    freeMatrice(lambda_carre,N);
    freeMatrice(lambda_i,N);
    freeMatrice(eta,N);
    freeMatrice(mat_mom,N);
    freeMatrice(CoeffLeg,N);

    return 0;
}

